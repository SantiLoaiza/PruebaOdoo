from odoo import models, fields

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    type = fields.Selection([
        ('national', 'National'),
        ('international', 'International')
    ], string='Type', required=True, default='national')

    project_id = fields.Many2one('project.project', string='Project')

    code = fields.Char(
        string='Code', 
        readonly=True, 
        default=lambda self: self.env['ir.sequence'].next_by_code('purchase.order.code')
    )

    user_partner_id = fields.Many2one('res.users', string='User')
